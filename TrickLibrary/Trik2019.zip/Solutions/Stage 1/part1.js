var __interpretation_started_timestamp__;
var pi = 3.1415926535897931;
 
num = mailbox.myHullNumber()
 
SL = brick.sensor("A1").read;
SR = brick.sensor("A2").read;
SF = brick.sensor("D1").read;
function SL_bin(){
	if (SL() < 40 ){
		return 1;
	}
	else{
		return 0;
	}
}

function SF_bin(){
	if (SF() < 40 ){
		return 1;
	}
	else{
		return 0;
	}
}

function SR_bin(){
	if (SR() < 40 ){
		return 1;
	}
	else{
		return 0;
	}
}


mailbox.connect("192.168.77.1");
 
function program_1(){
	while(true){
        	msg = SL_bin() + " " + SF_bin() + " " + SR_bin() + "*"
        	mailbox.send(2,msg)
       
        	while (!mailbox.hasMessages()){
        	    script.wait(100);
        	}
        	getter = mailbox.receive()
        	mailbox.send(2,getter)
        	getter = getter.split('*')
        	brick.display().addLabel(getter[0],10,10);
        	brick.display().addLabel(getter[1],10,30);
        	brick.display().addLabel(getter[2],10,50);
        	brick.display().redraw();
        	script.wait(100);
       
    	}
}

function program_2(){
	while(true){
       
        	while (!mailbox.hasMessages()){
        		script.wait(100);
        	}
        	getter = mailbox.receive()
       
       		msg = getter + SL_bin() + " " + SF_bin() + " " + SR_bin() + "*"
        	mailbox.send(3,msg)
        	while (!mailbox.hasMessages()){
        		script.wait(100);
        	}
        	getter = mailbox.receive().split('*')
        	brick.display().addLabel(getter[0],10,10);
        	brick.display().addLabel(getter[1],10,30);
        	brick.display().addLabel(getter[2],10,50);
        	brick.display().redraw();
        	script.wait(100);
       
	}	
}

function program_3(){
	while(true){
       
        	while (!mailbox.hasMessages()){
        		script.wait(100);
        	}
        	getter = mailbox.receive()
       
       		msg = getter + SL_bin() + " " + SF_bin() + " " + SR_bin()  
        	mailbox.send(1,msg)
       
       		getter = msg.split('*')
        	brick.display().addLabel(getter[0],10,10);
        	brick.display().addLabel(getter[1],10,30);
        	brick.display().addLabel(getter[2],10,50);
        	brick.display().redraw();
        	script.wait(100);
       
	}
}

 
var main = function()
{
    __interpretation_started_timestamp__ = Date.now();   
	script.wait(5000);
	if (num == 1){
		program_1();    
	}
	else if(num == 2){
		program_2();
	}
	else if(num == 3){
		program_3();
	}
   
	return;
}