// adj[i][j] содержит номер сектора, который находится по направлению 0 <= j <= 3 от i-ой сектора
// или -1 если такого нет
// Номер сектора pos с координатами x, y:
// pos = x + y*8
var adj = [[-1, 1, 8, -1], [-1, 2, -1, 0], [-1, 3, 10, 1], [-1, 4, -1, 2], [-1, 5, -1, 3], [-1, -1, 13, 4], [-1, -1, -1, -1], [-1, -1, 15, -1], [0, -1, 16, -1], [-1, -1, -1, -1], [2, -1, 18, -1], [-1, -1, 19, -1], [-1, -1, -1, -1], [5, 14, 21, -1], [-1, 15, -1, 13], [7, -1, -1, 14], [8, 17, -1, -1], [-1, 18, -1, 16], [10, -1, 26, 17], [11, 20, 27, -1], [-1, 21, -1, 19], [13, -1, 29, 20], [-1, -1, -1, -1], [-1, -1, 31, -1], [-1, -1, 32, -1], [-1, -1, -1, -1], [18, -1, 34, -1], [19, -1, -1, -1], [-1, -1, -1, -1], [21, 30, 37, -1], [-1, 31, -1, 29], [23, -1, 39, 30], [24, 33, 40, -1], [-1, 34, -1, 32], [26, 35, 42, 33], [-1, 36, -1, 34], [-1, 37, 44, 35], [29, -1, 45, 36], [-1, -1, -1, -1], [31, -1, -1, -1], [32, -1, -1, -1], [-1, -1, -1, -1], [34, -1, 50, -1], [-1, -1, -1, -1], [36, 45, -1, -1], [37, 46, 53, 44], [-1, 47, -1, 45], [-1, -1, 55, 46], [-1, 49, 56, -1], [-1, 50, -1, 48], [42, 51, 58, 49], [-1, -1, 59, 50], [-1, -1, -1, -1], [45, -1, -1, -1], [-1, -1, -1, -1], [47, -1, 63, -1], [48, -1, -1, -1], [-1, -1, -1, -1], [50, 59, -1, -1], [51, 60, -1, 58], [-1, 61, -1, 59], [-1, 62, -1, 60], [-1, 63, -1, 61], [55, -1, -1, 62]];

// Начальные позиции роботов
var robot_pos = [0, 0, 0];
var robot_dir = [0, 0, 0];

var finish_dir = 0;

function includes(array, element) {
	for (var i = 0; i < array.length; i++)
		if (array[i] == element)
			return true;
	return false;
}

// Возвращает маршрут позиции (start_pos; start_dir) в сектор finish_pos для робота с номером robot
// или null если маршрута не существует
// Маршрут представляет из себя строку из символов ["F" (forward), "L" (turn left), "R" (turn right)]
// Алгоритм поиска ширины по позициям [pos, dir] гарантирует оптимальность по длине строки (количество действий)
function get_path(robot, start_pos, start_dir, finish_pos) {
	// from[node][dir] - как попали в данную позицию
	// "F" если проездом вперед
	// "R" если поворотом направо
	// "L" если поворотом налево
	// "N" иначе (никак)
	from = [];
	for (var node = 0; node < 64; ++node) {
		from[node] = [];
		for (var dir = 0; dir < 4; ++dir)
			from[node][dir] = "N";
	}
	// Очередь для алгоритма поиска в ширину
	queue = [];
	queue.push([start_pos, start_dir]);
	while (queue.length > 0) { // Пока не перебрали все секции
		var tmp = queue.shift();
		var cur_pos = tmp[0];
		var cur_dir = tmp[1];
		if (cur_pos == finish_pos) { // Если нашли нужную секцию
			finish_dir = cur_dir;
			break;
		}
		// Проезд вперед
		if (adj[cur_pos][cur_dir] != -1) {
			var adj_pos = adj[cur_pos][cur_dir];
			var adj_dir = cur_dir;
			if (from[adj_pos][adj_dir] == "N" && !(includes(robot_pos, adj_pos) && adj_pos != robot_pos[robot])) {
				from[adj_pos][adj_dir] = "F";
				queue.push([adj_pos, adj_dir]);
			}
		}
		// Поворот направо
		if (from[cur_pos][(cur_dir + 1) % 4] == "N") { // Направо
			var adj_pos = cur_pos;
			var adj_dir = (cur_dir + 1) % 4;
			from[adj_pos][adj_dir] = "R";
			queue.push([adj_pos, adj_dir]);
		}
		// Поворот налево
		if (from[cur_pos][(cur_dir + 3) % 4] == "N") { // Налево
			var adj_pos = cur_pos;
			var adj_dir = (cur_dir + 3) % 4;
			from[adj_pos][adj_dir] = "L";
			queue.push([adj_pos, adj_dir]);
		}
	}
	// Восстановление пути
	var path = "";
	if (from[finish_pos][finish_dir] == "N")
		return null;
	else {
		var cur_pos = finish_pos;
		var cur_dir = finish_dir;
		while (cur_pos != start_pos|| cur_dir != start_dir) {
			var action = from[cur_pos][cur_dir];
			if (action == "F") {
				path = "F" + path;
				cur_pos = adj[cur_pos][(cur_dir + 2) % 4];
			} else if (action == "R") {
				path = "R" + path;
				cur_dir = (cur_dir + 3) % 4;
			} else if (action == "L") {
				path = "L" + path;
				cur_dir = (cur_dir + 1) % 4;
			}
		}
	}
	return path;
}

// Возвращает массив путей для каждого робота
// Возвращает ["", "", ""] если не удалось найти
// finish_pos - массив секторов куда должен добраться робот
function get_paths(finish_pos) {
	
	var result = ["", "", ""];
	var founded = [false, false, false];
	var ok = false;
	
	// Перебираем все возможные комбинация путей (сначала едет 1ый робот, потом 2ой и 3ий; 1-3-2; и т.д)
	function brute_force(paths) {
		if (founded[0] && founded[1] && founded[2]) {
			result = paths;
			ok = true;
			return;
		}
		for (var i = 0; i < 3; i++)
			if (!founded[i]) {
				var tmp = get_path(i, robot_pos[i], robot_dir[i], finish_pos[i]);
				if (tmp === null)
					continue;
				founded[i] = true;
				var new_paths = paths.slice();
				var old_pos = robot_pos[i];
				robot_pos[i] = finish_pos[i];
				new_paths[i] = new_paths[i] + tmp;
				for (var j = 0; j < 3; j++)
					while (new_paths[j].length < new_paths[i].length)
						new_paths[j] = new_paths[j] + "S";
				brute_force(new_paths);
				robot_pos[i] = old_pos;
				founded[i] = false;
			}
	}
	
	brute_force(["", "", ""]);
	
	// Если удалось найти путь
	if (ok)
		return result;
	
	var positions = [0, 1, 8, 44, 51];
	
	// Для каждого робота попробовать проехать в позиции, заданные в массиве positions
	for (var robot = 0; robot < 3; robot++) {
		for (var i = 0; i < positions.length; i++) {
			// Попробовать поехать в position[i]
			console.log("robot=" + robot + " pos=" + positions[i] + " path=" + path);
			var path = get_path(robot, robot_pos[robot], robot_dir[robot], positions[i]);
			if (path) {
				var old_pos = robot_pos[robot];
				var old_dir = robot_dir[robot];
				robot_pos[robot] = positions[i];
				robot_dir[robot] = finish_dir;
				var paths = ["", "", ""];
				paths[robot] = path;
				for (var j = 0; j < 3; j++)
					while (paths[j].length < paths[robot].length)
						paths[j] = paths[j] + "S";
				brute_force(paths);
				if (ok)
					return result;
				robot_pos[robot] = old_pos;
				robot_dir[robot] = old_dir;
			}
		}
	}
	
	return null;
}


var main = function() {
	robot_pos = [];
	robor_dir = [];
	var finish_pos = [];
	for (var i = 0; i < 3; i++) {
		inp = script.readAll("input.txt");
		Xs = parseInt(inp[i][0],10) //Start X
		Ys = parseInt(inp[i][2],10) //Start Y
		Ds = parseInt(inp[i][4],10) //Start direction
		Xf = parseInt(inp[i][6],10) //Finish X
		Yf = parseInt(inp[i][8],10) //Finish Y
		print(Xs,Ys,Ds,Xf,Yf)
		robot_pos[i] = Xs + Ys * 8;
		robot_dir[i] = Ds;
		finish_pos[i] = Xf + Yf * 8;
	}
	var paths = get_paths(finish_pos); //пути
	s = "1" + paths[0] + "2" + paths[1] + "3" + paths[2]
	script.writeToFile("output.txt", s);
	brick.display().addLabel("finish",1,1)
	brick.display().redraw()
	script.wait(10)
	// TODO: Вывести массив путей paths
}