var __interpretation_started_timestamp__;
var pi = 3.1415926535897931;

// adj[i][j] содержит номер секции, которая находится по направлению 0 <= j <= 3 от i-ой секции (если такой нет)
// Номер секции pos с координатами x, y:
// pos = x + y*8
var adj = [[-1, 1, 8, -1], [-1, 2, -1, 0], [-1, 3, 10, 1], [-1, 4, -1, 2], [-1, 5, -1, 3], [-1, -1, 13, 4], [-1, -1, -1, -1], [-1, -1, 15, -1], [0, -1, 16, -1], [-1, -1, -1, -1], [2, -1, 18, -1], [-1, -1, 19, -1], [-1, -1, -1, -1], [5, 14, 21, -1], [-1, 15, -1, 13], [7, -1, -1, 14], [8, 17, -1, -1], [-1, 18, -1, 16], [10, -1, 26, 17], [11, 20, 27, -1], [-1, 21, -1, 19], [13, -1, 29, 20], [-1, -1, -1, -1], [-1, -1, 31, -1], [-1, -1, 32, -1], [-1, -1, -1, -1], [18, -1, 34, -1], [19, -1, -1, -1], [-1, -1, -1, -1], [21, 30, 37, -1], [-1, 31, -1, 29], [23, -1, 39, 30], [24, 33, 40, -1], [-1, 34, -1, 32], [26, 35, 42, 33], [-1, 36, -1, 34], [-1, 37, 44, 35], [29, -1, 45, 36], [-1, -1, -1, -1], [31, -1, -1, -1], [32, -1, -1, -1], [-1, -1, -1, -1], [34, -1, 50, -1], [-1, -1, -1, -1], [36, 45, -1, -1], [37, 46, 53, 44], [-1, 47, -1, 45], [-1, -1, 55, 46], [-1, 49, 56, -1], [-1, 50, -1, 48], [42, 51, 58, 49], [-1, -1, 59, 50], [-1, -1, -1, -1], [45, -1, -1, -1], [-1, -1, -1, -1], [47, -1, 63, -1], [48, -1, -1, -1], [-1, -1, -1, -1], [50, 59, -1, -1], [51, 60, -1, 58], [-1, 61, -1, 59], [-1, 62, -1, 60], [-1, 63, -1, 61], [55, -1, -1, 62]];

var robot_pos = 0;
var robot_dir = 0;
enc_l = brick.encoder("E1")
enc_r = brick.encoder("E2")
motor_l = brick.motor("M1").setPower
motor_r = brick.motor("M2").setPower

rotCnt = 0;

function sign(x) {
	if (x > 0) {
		return 1;
	} else if (x < 0) {
		return -1;
	} else {
		return 0;
	}
}

// Возвращает маршрут позиции (start_node; start_dir) в секцию finish_node, или null если маршрута не существует
// Маршрут представляет из себя строку из символов ["F" (forward), "L" (turn left), "R" (turn right)]
// Алгоритм поиска ширины по позициям [pos, dir] гарантирует оптимальность по длине строки (количество действий)
function get_path(start_pos, start_dir, finish_pos) {
	// from[node][dir] - как попали в данную позицию
	// "F" если проездом вперед
	// "R" если поворотом направо
	// "L" если поворотом налево
	// "N" иначе (никак)
	from = [];
	for (var node = 0; node < 64; ++node) {
		from[node] = [];
		for (var dir = 0; dir < 4; ++dir)
			from[node][dir] = "N";
	}
	// Очередь для алгоритма поиска в ширину
	queue = [];
	queue.push([start_pos, start_dir]);
	var finish_dir = 0;
	while (queue.length > 0) { // Пока не перебрали все секции
		var tmp = queue.shift();
		var cur_pos = tmp[0];
		var cur_dir = tmp[1];
		if (cur_pos == finish_pos) { // Если нашли нужную секцию
			finish_dir = cur_dir;
			break;
		}
		// Проезд вперед
		if (adj[cur_pos][cur_dir] != -1) {
			var adj_pos = adj[cur_pos][cur_dir];
			var adj_dir = cur_dir;
			if (from[adj_pos][adj_dir] == "N") {
				from[adj_pos][adj_dir] = "F";
				queue.push([adj_pos, adj_dir]);
			}
		}
		// Поворот направо
		if (from[cur_pos][(cur_dir + 1) % 4] == "N") { // Направо
			var adj_pos = cur_pos;
			var adj_dir = (cur_dir + 1) % 4;
			from[adj_pos][adj_dir] = "R";
			queue.push([adj_pos, adj_dir]);
		}
		// Поворот налево
		if (from[cur_pos][(cur_dir + 3) % 4] == "N") { // Налево
			var adj_pos = cur_pos;
			var adj_dir = (cur_dir + 3) % 4;
			from[adj_pos][adj_dir] = "L";
			queue.push([adj_pos, adj_dir]);
		}
	}
	// Восстановление пути
	var path = "";
	if (from[finish_pos][finish_dir] == "N")
		return null;
	else {
		cur_pos = finish_pos;
		cur_dir = finish_dir;
		while (cur_pos != start_pos|| cur_dir != start_dir) {
			var action = from[cur_pos][cur_dir];
			if (action == "F") {
				path = "F" + path;
				cur_pos = adj[cur_pos][(cur_dir + 2) % 4];
			} else if (action == "R") {
				path = "R" + path;
				cur_dir = (cur_dir + 3) % 4;
			} else if (action == "L") {
				path = "L" + path;
				cur_dir = (cur_dir + 1) % 4;
			}
		}
	}
	return path;
}

// Возвращает маршрут из секции start_x, start_y, start_dir в секцию finish_x, finish_y, или null если маршрута не существует
function get_path_xy(start_x, start_y, start_dir, finish_x, finish_y) {
	return get_path(start_x + start_y * 8, start_dir, finish_x + finish_y * 8);
}

// Проезд робота по заданному маршруту
function follow_path(path) {
	for (i = 0; i < path.length; i++) {

		if (path[i] == "R") {
			print(brick.gyroscope().read()[6]/1000)
			script.wait(2500)
			turn_right();
			script.wait(250);
			robot_dir = (robot_dir + 1) % 4;
		} else if (path[i] == "L") {
			print(brick.gyroscope().read()[6]/1000)
			script.wait(2500)
			turn_left();
			script.wait(250);
			robot_dir = (robot_dir + 3) % 4;
		} else if (path[i] == "F") {
			print(brick.gyroscope().read()[6]/1000)
			script.wait(2500)
			forward();
			script.wait(250);
			robot_pos = adj[robot_pos][robot_dir];
		}
	}
}

// Проезд робота в секцию finish_pos
function go_to(finish_pos) {
	var path = get_path(robot_pos, robot_dir, finish_pos);
	follow_path(path);
	return path;
}

fullRot = 0;
// Движение вперед на 1 клетку для робота с номером robot
function moveSmall(){ //небольшой проезд впере, чтобы встать по центру ячейки
	enc_r.reset()
	enc_l.reset()
	deg = (88/(pi*56))*360

	while((enc_l.read()+enc_r.read())/2 < deg){

		err =  brick.gyroscope().read()[6]/1000 - fullRot;

		motor_l(50-err*0.5)

		motor_r(50+err*0.5)

		script.wait(1);

		}
	stop()
}


function forward(robot) {
	enc_r.reset()
	enc_l.reset()

	deg = (700/(pi*56))*360
	
	direction = (rotCnt + 2) % 4 - 2;
	while((enc_l.read()+enc_r.read())/2 < deg) {
		gyro = brick.gyroscope().read()[6]/1000;
		if (direction == -2) {
			err = gyro + sign(gyro) * direction * 90
		} else {
			err =  gyro - direction * 90;	
		}
		motor_l(50-err*0.5)
		motor_r(50+err*0.5)
		script.wait(1);
	}
	stop()
}

// Поворот направо для робота с номером robot
function turn_right(robot) {
	enc_r.reset()
	enc_l.reset()
	
	deg = (174/56)*90
	motor_l(50)
	motor_r(-50)
	while(enc_l.read() < deg) {
		script.wait(1)
	}
	
	stop()
	
	rotCnt += 1;
}

// Поворот налево для робота с номером robot
function turn_left(robot) {
	enc_r.reset()
	enc_l.reset()

	deg = (174/56)*90
	deg = 280
	motor_l(-50)
	motor_r(50)
	while(enc_r.read() < deg)
		script.wait(1)
	stop()
	
	rotCnt -= 1;
}

function stop(){ //стоп моторов
	motor_r(0)
	motor_l(0)
	script.wait(50)
}

var main = function() {
	__interpretation_started_timestamp__ = Date.now();
	brick.gyroscope().calibrate(2000);
	script.wait(2050)

    moveSmall();
	inp = script.readAll('task1_0.txt')
	Xs = parseInt(inp[0][0],10)
	Ys = parseInt(inp[0][2],10)
	Ds = parseInt(inp[0][4],10)
	Xf = parseInt(inp[1][0],10)
	Yf = parseInt(inp[1][2],10)
	print(Xs,Ys,Ds,Xf,Yf)

	robot_pos = Xs + Ys * 8;
	robot_dir = Ds;
	var finish_pos = Xf + Yf * 8;
	var path = go_to(finish_pos);
	brick.display().addLabel(path,1,1) //вывод ответа
	brick.display().redraw()
	script.wait(5000)
}