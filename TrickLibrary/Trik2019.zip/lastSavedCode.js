var __interpretation_started_timestamp__;

var pi = 3.1415926535897931;

var magiclocal = function () { 

	wait = script.wait;

	sign = function(n) { return n > 0 ? 1 : n = 0 ? 0 : -1; }

	sqr = function(n) { return n * n; }

	sqrt = Math.sqrt;

	min = function(a, b) { return a < b ? a : b; }

	max = function(a, b) { return a > b ? a : b; }

	abs = Math.abs;

	sin = Math.sin;

	cos = Math.cos;

	round = Math.round;



	// adj[i][j] ???????? ????? ???????, ??????? ????????? ?? ??????????? 0 <= j <= 3 ?? i-?? ???????

	// ??? -1 ???? ?????? ???

	// ????? ??????? pos ? ???????????? x, y:

	// pos = x + y*8

	var adj = [[-1, 1, 8, -1], [-1, 2, -1, 0], [-1, 3, 10, 1], [-1, 4, -1, 2], [-1, 5, -1, 3], [-1, -1, 13, 4], [-1, -1, -1, -1], [-1, -1, 15, -1], [0, -1, 16, -1], [-1, -1, -1, -1], [2, -1, 18, -1], [-1, -1, 19, -1], [-1, -1, -1, -1], [5, 14, 21, -1], [-1, 15, -1, 13], [7, -1, -1, 14], [8, 17, -1, -1], [-1, 18, -1, 16], [10, -1, 26, 17], [11, 20, 27, -1], [-1, 21, -1, 19], [13, -1, 29, 20], [-1, -1, -1, -1], [-1, -1, 31, -1], [-1, -1, 32, -1], [-1, -1, -1, -1], [18, -1, 34, -1], [19, -1, -1, -1], [-1, -1, -1, -1], [21, 30, 37, -1], [-1, 31, -1, 29], [23, -1, 39, 30], [24, 33, 40, -1], [-1, 34, -1, 32], [26, 35, 42, 33], [-1, 36, -1, 34], [-1, 37, 44, 35], [29, -1, 45, 36], [-1, -1, -1, -1], [31, -1, -1, -1], [32, -1, -1, -1], [-1, -1, -1, -1], [34, -1, 50, -1], [-1, -1, -1, -1], [36, 45, -1, -1], [37, 46, 53, 44], [-1, 47, -1, 45], [-1, -1, 55, 46], [-1, 49, 56, -1], [-1, 50, -1, 48], [42, 51, 58, 49], [-1, -1, 59, 50], [-1, -1, -1, -1], [45, -1, -1, -1], [-1, -1, -1, -1], [47, -1, 63, -1], [48, -1, -1, -1], [-1, -1, -1, -1], [50, 59, -1, -1], [51, 60, -1, 58], [-1, 61, -1, 59], [-1, 62, -1, 60], [-1, 63, -1, 61], [55, -1, -1, 62]];



	// ???????? ??????? (?????? ????????? ???? [pos, dir])

	var states = [];



	// ????????????????? ???????

	var robot1_pos = 0;

	var robot1_dir = 0;





	// ????????????? ??????? ?? ????? ?????????? ??????? ???????

	function init_states() {

		states = [];

		for (var robot_pos = 0; robot_pos < adj.length; robot_pos++)

			for (var robot_dir = 0; robot_dir < 4; robot_dir++)

				states.push([robot_pos, robot_dir]);

	}



	// ???????? ????????????????? ??????

	// action - ???? ?? ???????? ["F" (forward), "L" (turn left), "R" (turn right)]

	function update_positions(action) {

		for (var state = states.length - 1; state >= 0; state--) {

			var is_ok = true;

			

			var robot_pos = states[state][0];

			var robot_dir = states[state][1];

			

			if (action == "F")

				robot_pos = adj[robot_pos][robot_dir];

			else if (action == "L")

				robot_dir = (robot_dir + 3) % 4;

			else if (action == "R")

				robot_dir = (robot_dir + 1) % 4;

				

			if (robot_pos == -1) {

				states.splice(state, 1);

			} else {

				states[state][0] = robot_pos;

				states[state][1] = robot_dir;

			}

		}

	}



	// ?????????? ????????? ??????? ???????

	function update_states() {

		// ????????? ? ????????

		var on_front = is_free_on_front();

		var on_left = is_free_on_left();

		var on_right = is_free_on_right();

		for (var state = states.length - 1; state >= 0; state--) {

			var is_ok = true;

			

			robot_pos = states[state][0];

			robot_dir = states[state][1];

			

			// ???????? ??????? ??????/?????/??????? ?? ??????

			

			var pos = adj[robot_pos][robot_dir];

			is_ok = is_ok && (on_front == (pos != -1));

			

			pos = adj[robot_pos][(robot_dir + 3) % 4];

			is_ok = is_ok && (on_left  == (pos != -1));

			

			pos = adj[robot_pos][(robot_dir + 1) % 4];

			is_ok = is_ok && (on_right == (pos != -1));

			

			if (!is_ok) 

				states.splice(state, 1);

		}

	}



	// ??????????? ???????, 

	// ?????????? true/false (??????? ?? ??????????????)

	function localization() {

		init_states();

		update_states();

		

		// ???????? ?? ??????? ?????? ????

		while (states.length > 1) {



			if (is_free_on_right()) {

				turn_right();

				update_positions("R");

				update_states();

				forward();

				update_positions("F");

			} else if (is_free_on_front()) {

				forward();

				update_positions("F");

			} else {

				turn_left();

				update_positions("L");

			}

			update_states();

		}

		

		if (states.length == 1) {

			robot1_pos = states[0][0];

			robot1_dir = states[0][1];

			return true;

		} else

			return false;

	}



	iRight = brick.sensor(A2) //???????????? ??????? ???????

	iLeft = brick.sensor(A1) //???????????? ?????? ???????

	iForward = brick.sensor(D1) //???????????? ????????? ???????

	enc_l = brick.encoder("E1") //???????????? ???????? ?????? ??????

	enc_r = brick.encoder("E2") //???????????? ???????? ?????? ??????

	motor_l = brick.motor("M1").setPower //???????????? ?????? ??????

	motor_r = brick.motor("M2").setPower //???????????? ??????? ??????



	rotCnt = 0; //?????????? ??? ???????????? ???????? (??? ????? ?????? ??? ???????? ?????????? -180 - 180)



	function sign(x) { //??????? ?????????? ???? ????? 

		if (x > 0) {

			return 1;

		} else if (x < 0) {

			return -1;

		} else {

			return 0;

		}

	}

	// ???????? ?? ????? ?? ??????

	function is_free_on_left() {

		return (iLeft.read() > 40)

	}



	// ???????? ?? ?????? ?? ??????

	function is_free_on_right() {

		return (iRight.read() > 40)

	}



	// ???????? ?? ??????? ?? ??????

	function is_free_on_front() {

		return (iForward.read() > 40)

	}



	fullRot = 0;

	// ???????? ?????? ?? 1 ?????? ??? ?????? ? ??????? robot

	function moveSmall(){ //????????? ?????? ??????, ????? ?????? ?? ?????? ??????

		enc_r.reset()

		enc_l.reset()

		deg = (88/(pi*56))*360



		while((enc_l.read()+enc_r.read())/2 < deg){



			err =  brick.gyroscope().read()[6]/1000 - fullRot;



			motor_l(50-err*0.5)



			motor_r(50+err*0.5)



			script.wait(1);



			}

		stop()

	}





	function forward(robot) { //???????? ?????? ?? ???? ??????

		enc_r.reset()

		enc_l.reset()



		deg = (700/(pi*56))*360

		

		direction = (rotCnt + 2) % 4 - 2;

		while((enc_l.read()+enc_r.read())/2 < deg) {

			gyro = brick.gyroscope().read()[6]/1000;

			if (direction == -2) {

				err = gyro + sign(gyro) * direction * 90

			} else {

				err =  gyro - direction * 90;	

			}

			motor_l(50-err*0.5)

			motor_r(50+err*0.5)

			script.wait(1);

		}

		stop()

	}



	// ??????? ??????? ??? ??????

	function turn_right() {

		enc_r.reset()

		enc_l.reset()

		

		deg = (174/56)*90

		motor_l(50)

		motor_r(-50)

		while(enc_l.read() < deg) {

			script.wait(1)

		}

		

		stop()

		

		rotCnt += 1;

	}



	// ??????? ?????? ??? ?????? 

	function turn_left() {

		enc_r.reset()

		enc_l.reset()



		deg = (174/56)*90

		deg = 280

		motor_l(-50)

		motor_r(50)

		while(enc_r.read() < deg)

			script.wait(1)

		stop()

		

		rotCnt -= 1;

	}



	function stop(){ //???? ???????

		motor_r(0)

		motor_l(0)

		script.wait(50)

	}



	main = function() {

		brick.gyroscope().calibrate(2000); //?????????? ?????????

		script.wait(2050)



		moveSmall() // ????????? ??????, ????? ?????? ?? ??????

		localization() //???????????



		x = robot1_pos % 8 //?????????? x ?????? 

		y = parseInt(robot1_pos / 8,10) //?????????? ? ??????

		teta = robot1_dir;	

		return [x,y,teta];

		// TODO: ??????? ????????????????? robot1_pos, robot1_dir

	}



	return this.main();

}



var main = function() { 

	var pos = magiclocal();
	var target = getARTagValue(script.readAll('input.txt').toString());


	trikTaxi.walls = ["3, 11", "10, 11", "15, 23", "18, 19", "16, 24", "26, 27", "27, 35", "39, 47", "40, 48", "53, 61"]

	var maze = [1, 1, 1, 1, 1, 1, 0, 1,

		    1, 0, 1, 1, 0, 1, 1, 1,

		    1, 1, 1, 1, 1, 1, 0, 1,

		    1, 0, 1, 1, 0, 1, 1, 1,

		    1, 1, 1, 1, 1, 1, 0, 1,

		    1, 0, 1, 0, 1, 1, 1, 1,

		    1, 1, 1, 1, 0, 1, 0, 1,

		    1, 0, 1, 1, 1, 1, 1, 1]

	script.wait(100);

	

	odometriya.Start();

	movementlib.start();

	

	switch (pos[2]) {

		case 0:

			var startTeta = pi / 2;

			break;

		case 1:

			var startTeta = 0;

			break;

		case 2:

			var startTeta = 1.5 * pi;

			break;

		case 3:

			var startTeta = pi;

			break;

	}

	odometriya.teta = startTeta;

	var path = trikTaxi.magicbfs(pos[0] + pos[1] * 8, target[0] + target[1] * 8, maze, 8, 8, startTeta / (2 * pi));

	movementlib.move_path(80, path, 8, 8, irLeftSensor, irRightSensor, uzFrontSensor, 1.1, 0.5, 0);

	display.print("finish");

	script.wait(6000);

}

	















































// –?????? ??????????€

height = 120, width = 160;



// «???? ????????€ ??????????? ? ???? ??????? ????? ? ??????

image = [];



// «??????€ ARTag ???????

values = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];



// ¬????????€ ??????? ? ???????? (??€??????????)

// iMin, iMax ?????? ?????????????? ??€???

// jMin, jMax ?????? ???????????? ??€???

iMin = 0, iMax = 0, jMin = 0, jMax = 0;



// ¬????????€ ??????? ? ????????

// 

// 

k1Min = 0, k1Max = 0, k2Min = 0, k2Max = 0;



// ”??? ARTag ??????????€

iA = 0, jA = 0, iB = 0, jB = 0, iC = 0, jC = 0, iD = 0, jD = 0;



//file1 = "9.txt"

//file2 = "9.clue"



// ????????? ????????

function getData(raw) {

	print("TEST: ", raw == undefined);

	if (raw == undefined)

		raw = getPhoto().toString();

	//print("------------")

	//print (raw[0]);

	//raw =  script.readAll("0.txt");

	raw = raw.split(",");

	

	

	//script.removeFile(file1)

	//script.writeToFile(file1, raw)

	

	script.wait(2000)

	for (i = 0; i < height; ++i) {

		image[i] = [];

		for (j = 0; j < width; ++j) {

			color = raw[i * width + j];

			// ????????? RGB ? grayscale

			image[i][j] = ((color & 0xff0000) >> 16) + ((color & 0xff00) >> 8) + (color & 0xff);

		}

	}

	// ??????? 

	for (i = 0; i < height; ++i) {

		for (j = 0; j < 4; j++){

			image[i][j] = 255 + 255 + 255;

		}

				

	}

	for (i = 0; i < width; ++i) {

		for (j = 0; j < 4; j++){

			image[j][i] = 255 + 255 + 255;

		}

				

	}

	

	// ‘??? ?? ???????? ????? (???? ?????? ?? ??????)

	for (i = height - 8; i < height; ++i) 

		for (j = 0; j < width; ++j)

			image[i][j] = 255 + 255 + 255;

}



// ?????????€ ??????????€, ???????????€ ??????? ??????????????

function binarization() {

	sum = 0;

	for (i = 0; i < height; ++i)

		for (j = 0; j < width; ++j)

			sum += image[i][j];

	mean = sum / height / width;

	for (i = 0; i < height; ++i)

		for (j = 0; j < width; ++j)

			image[i][j] = (4 * image[i][j] > mean ? 0 : 1);

}



// ¬???? ??????????€ ? ???????

// ????? ??????????? ? ??????????? ???????? ? Notepad++

function printImage() {

    for (i = 0; i < height; ++i) {

		str = "";

        for (j = 0; j < width; ++j)

			// ¬???? ????????? ???????

			// 0: ????? ???????

			// 1: ?????? ???????

			// 2-5: ???? ARTag ???????

			// 6: ???????? ?????

			str += ".#ABCD*"[image[i][j]] + " ";

        print(str);

    }

}



// ¬???? ??????????? ??????????€ ? ???????

function printSelectedImage() {

	for (i = iMin; i <= iMax; ++i) {

		str = "";

        for (j = jMin; j <= jMax; ++j)

			str += ".#ABCD*"[image[i][j]] + " ";

        print(str);

    }

}



// ????? ????? ARTag ???????

function getCorners() {

	iMin = 0, iMax = 0, jMin = 0, jMax = 0;

	k1Min = 0, k1Max = 0, k2Min = 0, k2Max = 0;

	iMin = height - 1, iMax = 0;

	jMin = width - 1, jMax = 0;

	k1Min = height + width, k1Max = 0;

	k2Min = height + width, k2Max = -width;

	for (i = 0; i < height; ++i)

		for (j = 0; j < width; ++j)

			if (image[i][j]) {

				iMin = min(iMin, i);

				iMax = max(iMax, i);

				jMin = min(jMin, j);

				jMax = max(jMax, j);

				k1Min = min(k1Min, i + j);

				k1Max = max(k1Max, i + j);

				k2Min = min(k2Min, i - j);

				k2Max = max(k2Max, i - j);

			}

	if (iMax - iMin < 35 || jMax - jMin < 35) {

		print("Error: ARTag is too small to read it\n");



		iA = 0, jA = 0;



		iB = 0, jB = width - 1;



		iC = height - 1, jC = width - 1;



		iD = height - 1, jD = 0;



		return;



	}

	//  ????????? ????? ???????? ??? ???????, ?? ? ?????????? ???????

	// ????? ??€ ??????????€ ???? ???????: ????? ??€??? / ??? ????????

	countOfWhite = 0;

	for (i = iMin; i <= iMax; ++i) {

		j = jMin;

		while (j <= jMax && !image[i][j])

			++j, ++countOfWhite;

		if (j < jMax) {

			j = jMax;

			while (j >= jMin && !image[i][j])

				--j, ++countOfWhite;

		}

	}

	// ˜??? ARTag ?????? ????????, ???? ???? ? ?????

	if (countOfWhite * 2 > (iMax - iMin + 1) * (jMax - jMin + 1)) {

		// Point A

		i1 = iMin, i2 = iMax;

		while (!image[i1][jMin]) ++i1;

		while (!image[i2][jMin]) --i2;

		iA = round((i1 + i2) / 2), jA = jMin;

		// Point B

		j1 = jMin, j2 = jMax;

		while (!image[iMin][j1]) ++j1;

		while (!image[iMin][j2]) --j2;

		iB = iMin, jB = round((j1 + j2) / 2);

		// Point C

		i1 = iMin, i2 = iMax;

		while (!image[i1][jMax]) ++i1;

		while (!image[i2][jMax]) --i2;

		iC = round((i1 + i2) / 2), jC = jMax;

		// Point D

		j1 = jMin, j2 = jMax;

		while (!image[iMax][j1]) ++j1;

		while (!image[iMax][j2]) --j2;

		iD = iMax, jD = round((j1 + j2) / 2);

	} else { // ˜??? ????? ??€??, ???? ???? ?? ????????€?

		// Point A

		i1 = iMin, i2 = k1Min - jMin;

		while (!image[i1][k1Min - i1]) ++i1;

		while (!image[i2][k1Min - i2]) --i2;

		iA = round((i1 + i2) / 2), jA = k1Min - iA;

		// Point B

		i1 = iMin, i2 = k2Min + jMax;

		while (!image[i1][i1 - k2Min]) ++i1;

		while (!image[i2][i2 - k2Min]) --i2;

		iB = round((i1 + i2) / 2), jB = iB - k2Min;

		// Point C

		i1 = k1Max - jMax, i2 = iMax;

		while (!image[i1][k1Max - i1]) ++i1;

		while (!image[i2][k1Max - i2]) --i2;

		iC = round((i1 + i2) / 2), jC = k1Max - iC;

		// Point D

		i1 = k2Max + jMin, i2 = iMax;

		while (!image[i1][i1 - k2Max]) ++i1;

		while (!image[i2][i1 - k2Max]) --i2;

		iD = round((i1 + i2) / 2), jD = iD - k2Max;

	}

	// –????????????????, ???? ?????? ????? ??????? ??????????? ? ???????, »??„˜ ?˜ ?”ƒ˜“ –???“?“? –?—???«??¬??»˜ „»—??

    // image[iA][jA] = 2;

    // image[iB][jB] = 3;

    // image[iC][jC] = 4;

    // image[iD][jD] = 5;

}



// 3 points and vector from 3th point

function intersect1(i1, j1, i2, j2, i3, j3, di, dj) {

	k1 = (i1 == i2 ? 1e6 : (j2 - j1) / (i2 - i1));

	b1 = j1 - k1 * i1;

	k2 = (i3 + di == i3 ? 1e6 : dj / di);

	b2 = j3 - k2 * i3;

	x3 = (b2 - b1) / (k1 - k2);

	y3 = k1 * x3 + b1;

	return [round(x3), round(y3)];

}



// 4 points

function intersect2(i1, j1, i2, j2, i3, j3, i4, j4) {

	k1 = (i1 == i2 ? 1e6 : (j2 - j1) / (i2 - i1));

	b1 = j1 - k1 * i1;

	k2 = (i3 == i4 ? 1e6 : (j4 - j3) / (i4 - i3));

	b2 = j3 - k2 * i3;

	i = (b2 - b1) / (k1 - k2);

	j = k1 * i + b1;

	return [round(i), round(j)];

}



// »??? ???????? ????? ARTag ??????? (?? ???, ?? ??? ????????, ??? ????? ???? ????? »????)

function findPoint(){

	A = [iA, jA];

	B = [iB, jB];

	C = [iC, jC];

	D = [iD, jD];



	AB = [B[0] - A[0], B[1] - A[1]];

	BC = [C[0] - B[0], C[1] - B[1]];

	DC = [C[0] - D[0], C[1] - D[1]];

	AD = [D[0] - A[0], D[1] - A[1]];



	O = intersect2(A[0], A[1], C[0], C[1], B[0], B[1], D[0], D[1]);

	

	E = intersect1(B[0], B[1], C[0], C[1], O[0], O[1], AB[0] + DC[0], AB[1] + DC[1]);

	K = intersect1(A[0], A[1], D[0], D[1], O[0], O[1], -AB[0] - DC[0], -AB[1] - DC[1]);

	L = intersect1(C[0], C[1], D[0], D[1], O[0], O[1], AD[0] + BC[0], AD[1] + BC[1]);

	M = intersect1(A[0], A[1], B[0], B[1], O[0], O[1], -AD[0] - BC[0], -AD[1] - BC[1]);

	

	W1 = intersect2(M[0], M[1], E[0], E[1], B[0], B[1], D[0], D[1]);

	W2 = intersect2(E[0], E[1], L[0], L[1], A[0], A[1], C[0], C[1]);

	W3 = intersect2(K[0], K[1], L[0], L[1], B[0], B[1], D[0], D[1]);

	W4 = intersect2(M[0], M[1], K[0], K[1], A[0], A[1], C[0], C[1]);

	

	H1 = intersect2(W1[0], W1[1], W2[0], W2[1], K[0], K[1], E[0], E[1]);

	H2 = intersect2(W2[0], W2[1], W3[0], W3[1], L[0], L[1], M[0], M[1]);

	H3 = intersect2(W3[0], W3[1], W4[0], W4[1], K[0], K[1], E[0], E[1]);

	H4 = intersect2(W4[0], W4[1], W1[0], W1[1], L[0], L[1], M[0], M[1]);

	

	Z1 = intersect2(O[0], O[1], W1[0], W1[1], H4[0], H4[1], H1[0], H1[1]);

	Z2 = intersect2(O[0], O[1], W2[0], W2[1], H1[0], H1[1], H2[0], H2[1]);

	Z3 = intersect2(O[0], O[1], W3[0], W3[1], H2[0], H2[1], H3[0], H3[1]);

	Z4 = intersect2(O[0], O[1], W4[0], W4[1], H3[0], H3[1], H4[0], H4[1]);

	

	T1 = intersect2(H4[0], H4[1], W1[0], W1[1], Z1[0], Z1[1], Z2[0], Z2[1]);

	T2 = intersect2(W1[0], W1[1], H1[0], H1[1], Z1[0], Z1[1], Z4[0], Z4[1]);	

	T3 = intersect2(H1[0], H1[1], W2[0], W2[1], Z2[0], Z2[1], Z3[0], Z3[1]);

	T4 = intersect2(W2[0], W2[1], H2[0], H2[1], Z2[0], Z2[1], Z1[0], Z1[1]);

	T5 = intersect2(H2[0], H2[1], W3[0], W3[1], Z3[0], Z3[1], Z4[0], Z4[1]);

	T6 = intersect2(W3[0], W3[1], H3[0], H3[1], Z3[0], Z3[1], Z2[0], Z2[1]);

	T7 = intersect2(H3[0], H3[1], W4[0], W4[1], Z4[0], Z4[1], Z1[0], Z1[1]);

	T8 = intersect2(W4[0], W4[1], H4[0], H4[1], Z4[0], Z4[1], Z3[0], Z3[1]);

	

	

	values[0][0] = image[W4[0]][W4[1]];

	values[0][1] = image[T8[0]][T8[1]];

	values[0][2] = image[T1[0]][T1[1]];

	values[0][3] = image[W1[0]][W1[1]];

	values[1][0] = image[T7[0]][T7[1]];

	values[1][1] = image[Z4[0]][Z4[1]];

	values[1][2] = image[Z1[0]][Z1[1]];

	values[1][3] = image[T2[0]][T2[1]];

	values[2][0] = image[T6[0]][T6[1]];

	values[2][1] = image[Z3[0]][Z3[1]];

	values[2][2] = image[Z2[0]][Z2[1]];

	values[2][3] = image[T3[0]][T3[1]];

	values[3][0] = image[W3[0]][W3[1]];

	values[3][1] = image[T5[0]][T5[1]];

	values[3][2] = image[T4[0]][T4[1]];

	values[3][3] = image[W2[0]][W2[1]];

	

	image[H1[0]][H1[1]] = 6;

	image[W1[0]][W1[1]] = 6;

	image[W2[0]][W2[1]] = 6;

	image[H4[0]][H4[1]] = 6;

	image[O[0]][O[1]] = 6;

	image[H2[0]][H2[1]] = 6;

	image[W4[0]][W4[1]] = 6;

	image[H3[0]][H3[1]] = 6;

	image[W3[0]][W3[1]] = 6;

	image[T1[0]][T1[1]] = 6;

	image[T2[0]][T2[1]] = 6;

	image[T3[0]][T3[1]] = 6;

	image[T4[0]][T4[1]] = 6;

	image[T5[0]][T5[1]] = 6;

	image[T6[0]][T6[1]] = 6;

	image[T7[0]][T7[1]] = 6;

	image[T8[0]][T8[1]] = 6;

	image[Z1[0]][Z1[1]] = 6;

	image[Z2[0]][Z2[1]] = 6;

	image[Z3[0]][Z3[1]] = 6;

	image[Z4[0]][Z4[1]] = 6;





}



function rotate_clockwise(times){

	for (i = 0; i < times; i = i + 1){

		values_temp = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];

		for (j = 0; j < 4; j = j + 1){

			for (z = 0; z < 4; z = z + 1){

				values_temp[z][3-j] = values[j][z]

			}

		}

		values = values_temp;

	}

}



// ¬????????? ???????? ARTag 

function getARTagValue(raw) {

	getData(raw);

	binarization();

	//printImage();

	getCorners();

	findPoint();

	//printImage();

	X = -1; Y = -1; NUM = -1;

	if (values[0][0] == 0 && values[0][3] == 1 && values[3][3] == 1 && values[3][0] == 1){

		rotate_clockwise(2);

	}

	else if (values[0][3] == 0 && values[0][0] == 1 && values[3][3] == 1 && values[3][0] == 1){

		rotate_clockwise(1);

	}

	else if (values[3][3] == 0 && values[0][3] == 1 && values[0][0] == 1 && values[3][0] == 1){

	}

	else if (values[3][0] == 0 && values[0][3] == 1 && values[3][3] == 1 && values[0][0] == 1){

		rotate_clockwise(3)

	}

	else{

		print("Error: Incorrect ARTag\n");

		return [X, Y, NUM];

	}

	X = values[1][3] * 4 + values[2][0] * 2 + values[2][2];

	Y = values[2][3] * 4 + values[3][1] * 2 + values[3][2];

	NUM = values[1][0] * 2 + values[1][2];

	string = "" + X + " " + Y + " " + NUM;

	

	// brick.display().addLabel(string,10,10);	

	return [X, Y, NUM];

}





















































































































//Controllers

var controllers = [{}, {}, {}]

controllers[0].name = "trik-52aee1"

controllers[1].name = "trik-f657a8"

controllers[2].name = "trik-67ae70"

controllers[0].ip = "192.168.77.1"

controllers[1].ip = "192.168.77.204"

controllers[2].ip = "192.168.77.221"

controllers[2].kp = 1.1;

controllers[2].kd = 0.5;

controllers[2].ki = 0;

controllers[0].cprl = 392;

controllers[0].cprr = 392;

controllers[1].cprl = 366;

controllers[1].cprr = 326;

controllers[2].cprl = 394;

controllers[2].cprr = 394; 

/*

Status:

0 - finished

1 - executing

*/

controllers[0].status = 0 

controllers[1].status = 0

controllers[2].status = 0



// Robot's settings

var pi = 3.141592653589793;

var d = 5.6 // wheels' diameter, cm

var l = 17.5 // Robot's base, cm

var sensorOffsetLeft = 0;

var sensorOffsetFront = 0;

var degInRad = 180 / pi;

var cmtodeg = (pi*56)/3600;



// Motors

var mLeft = brick.motor(M1).setPower; // Default left motor in 2D simulator

var mRight = brick.motor(M2).setPower; // Default right motor in 2D simulator

var mLeftGet = brick.motor(M1).power; // Default left motor in 2D simulator

var mRightGet = brick.motor(M2).power; // Default right motor in 2D simulator

var cpr = 360 // Encoder's count per round of wheel //350

var cpr0 = 394;

var cprToDeg = 360/cpr;

var kp2 = 1.1;

var kd2 = 0.5;

var ki2 = 0;



// Encoders

var eLeft = brick.encoder(E1); // Default left encoder in 2D simulator

var eRight = brick.encoder(E2); // Default right encoder in 2D simulator

eLeft.reset();

eRight.reset();



//Sensors

var uzFrontSensor = brick.sensor(D1);//??????????????

var uzBackSensor = brick.sensor(D2);//??????????????

var irRightSensor = brick.sensor(A2);//????????????

var irLeftSensor = brick.sensor(A1);//????????????

//var tRightSensor = brick.sensor(A3);//???????

//var tLeftSensor = brick.sensor(A4);//???????

//var lRightSensor = brick.sensor(A5);//????????????

//var lLeftSensor = brick.sensor(A6);//????????????





// Cell's parameters

var cellLength = 52.5 * cpr / (pi * d);

var length = 70;



//Gyroscope settings

var timeCalibrateRealRobot = 10000;

var timeCalibrate2DRobot = 2000;

// ??????? ???????? ?? x

//brick.gyroscope().read()[0]; 

// ??????? ???????? ?? y

//brick.gyroscope().read()[1];

// ??????? ???????? ?? z

//brick.gyroscope().read()[2];

//brick.gyroscope().read()[3]; // Valid time at gyroscope measurement

// ???? ???????? ? ????????????? -180 000 ?? 180 000

//var az = brick.gyroscope().read()[6];

// ???? ??????? ? ????????????? -180 000 ?? 180 000

//var ax = brick.gyroscope().read()[4];

// ???? ????? ? ????????????? -90 000 ?? 90 000

//var ay = brick.gyroscope().read()[5];

















































//##################

//REGION: ODOMETRIYA

//##################

/*

Usage:

Add 'Start' method when initializing.

Also, you have to call 'Reset' method when you're making a reset of the encoders

Or 'ResetRight' and 'ResetLeft' instead of 'eRight.reset' and 'eLeft.reset'

You can change 'deltat' according to the loop delay value. For example: 

	while(true) { odometriya.Update(); script.wait(10); }

	> Change deltat to 10

*/

//This code requiers:

//+ eLeft, eRight, pi, cpr, d, l

var odometriya = {}



//These variables are based on the given task

//If they're known then you should update them here:

odometriya.x = 0

odometriya.y = 0

odometriya.distance = 0

odometriya.lDistance = 0

odometriya.rDistance = 0

odometriya.teta = 0 //90* = pi / 2; 180* = pi; 270* = 1.5 * pi; 360* = 2 * pi

//This is the delay between iterations inside the main loop (<Your MS Delay> / 1000)

//If this value is 0 then it'll be calculated automatically (!but less accurate!)

odometriya.deltat = 10 / 1000

odometriya.updatedelay = 10



//These are the local ones (don't edit them):

odometriya.lastrawleft = 0

odometriya.lastrawright = 0

odometriya.lasttime = Date.now()



odometriya.ResetLeft = function() {

	odometriya.lastrawleft = 0

	odometriya.lastrawright = eRight.read();

	eLeft.reset();

	odometriya.lasttime = Date.now()

}



odometriya.ResetRight = function() {

	odometriya.lastrawright = 0

	odometriya.lastrawleft = eLeft.read();

	eRight.reset();

	odometriya.lasttime = Date.now()

}



odometriya.Reset = function() {

	odometriya.lastrawleft = 0

	odometriya.lastrawright = 0

	eLeft.reset();

	eRight.reset();

	odometriya.lasttime = Date.now()

}



odometriya.Update = function() {

	var lvar = {}

	lvar.deltat = (Date.now() - odometriya.lasttime) / 1000;



	if (lvar.deltat == 0) {

		return;

	}

	if (odometriya.deltat > 0) {

		lvar.deltat = odometriya.deltat;

	}

	

	lvar.rawleft = eLeft.read();

	lvar.rawright = eRight.read();

	

	lvar.deltaleft = lvar.rawleft - odometriya.lastrawleft;

	lvar.deltaright = lvar.rawright - odometriya.lastrawright;

	

	//lvar.vleft = pi * d * (lvar.deltaleft / cpr) / lvar.deltat;

	//lvar.vright = pi * d * (lvar.deltaright / cpr) / lvar.deltat;

	lvar.vleft = pi * d * (lvar.deltaleft / cpr) / lvar.deltat;

	lvar.vright = pi * d * (lvar.deltaright / cpr) / lvar.deltat;

	

	lvar.v = (lvar.vleft + lvar.vright) / 2;

	lvar.w = (lvar.vright - lvar.vleft) / l;

	

	lvar.deltateta = lvar.w * lvar.deltat;

	odometriya.x += Math.cos(odometriya.teta) * lvar.v * lvar.deltat;

	odometriya.y += Math.sin(odometriya.teta) * lvar.v * lvar.deltat;

	odometriya.distance += Math.abs(lvar.v * lvar.deltat);

	odometriya.lDistance += Math.abs(lvar.vleft * lvar.deltat);

	odometriya.rDistance += Math.abs(lvar.vright * lvar.deltat);

	odometriya.teta += lvar.deltateta;

	

	

	//print("GyroTETA = " + (-brick.gyroscope().read()[6] * pi ) / 180000);//GYROSCOPE ANGLE(PblCKAHIE)

	//print("x: " + odometriya.x); //<<<<<<< DEBUG TUUUT <<<<<<<<

	//print("y: " + odometriya.y);

	//print("teta: " + odometriya.teta);

	//print("distance: " + odometriya.distance);

	//print("x_cell: " + Math.round(odometriya.x / length));

	//print("y_cell: " + Math.round(odometriya.y / length));

	//print("distance_cell: " + Math.round(odometriya.distance / length));

	

	odometriya.lastrawleft = lvar.rawleft;

	odometriya.lastrawright = lvar.rawright;

	odometriya.lasttime = Date.now();

}



odometriya.Start = function() {

	var lvar = {}

	lvar.updateTimer = script.timer(odometriya.updatedelay);

	lvar.updateTimer.timeout.connect(odometriya.Update);

}

//##################

//REGION END

//##################





//##################

//REGION ODOMETRIYA MOVEMENT

//##################

//This code requiers:

//+ Odometriya module

//+ eLeft, eRight, pi, cpr, d, l



var movementlib = {}



movementlib.cellsize = 70

//kp recommended: = 2.5

//kd recommended: = 0.1

movementlib.correctiondelay = 5

movementlib.sensorscorrectiondelay = 50

//movementlib.correctionthreshold = length / 1.5; //for real



movementlib.correctionthreshold = length / 1.6; //for sim

movementlib.updatedelay = 5



//Local variables (don't TOUCH111)

movementlib.flStop = 0

movementlib.mLeftValue = 0

movementlib.mRightValue = 0

movementlib.mTargetLeft = 0

movementlib.mTargetRight = 0

movementlib.lerp = 0.1



movementlib.update = function() {

	movementlib.mLeftValue = movementlib.mLeftValue + movementlib.lerp * movementlib.updatedelay * (movementlib.mTargetLeft - movementlib.mLeftValue);

	movementlib.mRightValue = movementlib.mRightValue + movementlib.lerp * movementlib.updatedelay * (movementlib.mTargetRight - movementlib.mRightValue);

	mLeft(movementlib.mLeftValue);

	mRight(movementlib.mRightValue);

}



//Call this on start

movementlib.start = function() {

	var updateTimer = script.timer(movementlib.updatedelay);

	updateTimer.timeout.connect(movementlib.update);

}



movementlib.mleft = function(vel) {

	if (!isNaN(vel))

		movementlib.mTargetLeft = vel;

}



movementlib.mright = function(vel) {

	if (!isNaN(vel))

		movementlib.mTargetRight = vel;

}



movementlib.mleftforce = function(vel) {

	if (!isNaN(vel)) {

		movementlib.mleft(vel);

		movementlib.mLeftValue = vel;

	}

}



movementlib.mrightforce = function(vel) {

	if (!isNaN(vel)) {

		movementlib.mright(vel);

		movementlib.mRightValue = vel;

	}

}



/*

Stops all the movements

*/

movementlib.stop = function() {

	movementlib.flStop = 1;

}



movementlib.unfreeze = function() {

	movementlib.flStop = 0;

}



/*

Angle - rad

*/

movementlib.rotate_encoders = function(speed, angle) {

	var lvar = {}

	if (angle == 0) {

		return;

	}

	lvar.initialAngle = odometriya.teta;

	if (angle > 0) {

		movementlib.mleft(-speed);

		movementlib.mright(speed);

		//mLeft(-speed)

		//mRight(speed)

	} else {

		//mLeft(speed);

		//mRight(-speed);

		movementlib.mleft(speed);

		movementlib.mright(-speed);

	}

	

	while (true) {

		if ((angle > 0 && (odometriya.teta - lvar.initialAngle) >= angle) || 

			(angle < 0 && (odometriya.teta - lvar.initialAngle) <= angle)) { break; }

		if (movementlib.flStop) break;

		//var deltaAngle = (odometriya.teta - lvar.initialAngle) / angle;

		//var vel = Math.max(0.8, Math.min(deltaAngle, 1 - deltaAngle) * 2); //max in the middle

		//movementlib.mleft(speed);

		//movementlib.mright(-speed);

		script.wait(1);

	}

	//movementlib.mleft(0);

	//movementlib.mright(0);

	//mLeft(0);

	//mRight(0);

	movementlib.mleftforce(0);

	movementlib.mrightforce(0);

}



movementlib.rotate_encoderssmooth = function(speed, angle) {

	var lvar = {}

	if (angle == 0) {

		return;

	}

	lvar.initialAngle = odometriya.teta;

	if (angle > 0) {

		lvar.initLeft = -speed;

		lvar.initRight = speed;

		//movementlib.mleft(-speed);

		//movementlib.mright(speed);

		//mLeft(-speed)

		//mRight(speed)

	} else {

		//mLeft(speed);

		//mRight(-speed);

		lvar.initLeft = speed;

		lvar.initRight = -speed;

		//movementlib.mleft(speed);

		//movementlib.mright(-speed);

	}

	

	while (true) {

		if ((angle > 0 && (odometriya.teta - lvar.initialAngle) >= angle) || 

			(angle < 0 && (odometriya.teta - lvar.initialAngle) <= angle)) { break; }

		if (movementlib.flStop) break;

		var progress = (odometriya.teta - lvar.initialAngle) / angle; //0 - 1

		var progressD = Math.min(progress, 1 - progress) * 1.7;

		var velPower = Math.max(progressD, 0.3);

		//print(velPower);

		movementlib.mleftforce(lvar.initLeft * velPower);

		movementlib.mrightforce(lvar.initRight * velPower);

		script.wait(1);

	}

	//movementlib.mleft(0);

	//movementlib.mright(0);

	//mLeft(0);

	//mRight(0);

	movementlib.mleftforce(0);

	movementlib.mrightforce(0);

}



/*

Angle - rad

*/

movementlib.rotate_absolute = function(speed, angle) {

	var delta_angle = -odometriya.teta + angle;

	movementlib.rotate_encoders(speed, delta_angle);

}



movementlib.look_at = function(speed, x, y) {

	var delta = [x - odometriya.x, y - odometriya.y];

	var delta_angle = -odometriya.teta + Math.atan2(delta[1], delta[0]);

	movementlib.rotate_encoders(speed, delta_angle);

}



/*

Distance - cm

*/

movementlib.move_encoders = function(speed, distance) {

	var lvar = {}

	lvar.initialDistance = odometriya.distance;

	movementlib.mleft(speed);

	movementlib.mright(speed);

	while (odometriya.distance - lvar.initialDistance < distance) {

		if (movementlib.flStop) break;

		script.wait(1);

	}

	movementlib.mleft(0);

	movementlib.mright(0);

}



movementlib.initCorrect = function(speed, sLeft, sRight, sFront) {

	var leftD = sLeft != undefined ? sLeft.read() : Infinity;

	var rightD = sRight != undefined ? sRight.read() : Infinity;

	var frontD = sFront != undefined ? sFront.read() : Infinity;

	var leftD = Math.min(leftD, length);

	var rightD = Math.min(rightD, length);

	var frontD = Math.min(frontD, length);

	var initD = Infinity;

	var sCorrector = undefined;

	if (leftD != length) {

		//Correct using the left one

		//print("Left");

		initD = leftD;

		sCorrector = sLeft;

		

	} else if (frontD != length) {

		//Correct using the front one;

		//print("Front");

		initD = frontD;

		sCorrector = sFront;

		

	} else if (rightD != length) {

		//Correct using the right one

		//print("Right");

		initD = rightD;

		sCorrector = sRight;

		

	} else {

		return; 

	}

	

	var lastD = Infinity;

	

	while(sCorrector.read() <= lastD) {

		//print("First: " + sCorrector.read());

		movementlib.mleft(speed);

		movementlib.mright(-speed);

		lastD = sCorrector.read();

		script.wait(30);

	}

	movementlib.mleftforce(0);

	movementlib.mrightforce(0);

	

	if (lastD >= initD) {

		lastD = Infinity;

		

		while(sCorrector.read() <= lastD) {

			//print("Second: " + sCorrector.read());

			movementlib.mleft(-speed);

			movementlib.mright(speed);

			lastD = sCorrector.read();

			script.wait(30);

		}

	}

	

	movementlib.mleftforce(0);

	movementlib.mrightforce(0);

}



//TODO: ERROR HAS TO BE A DIFFERENCE BETWEEN THE MAIN LINE AND CONTROLLER'S POSITION

movementlib.move_correction = function(speed, distance, kp, kd) {

	var lvar = {}

	lvar.initX = odometriya.x;

	lvar.initY = odometriya.y;

	lvar.initT = odometriya.teta;

	lvar.initialDistance = odometriya.distance;

	lvar.lInitialDistance = odometriya.lDistance;

	lvar.rInitialDistance = odometriya.rDistance;

	lvar.integral = 0;

	//movementlib.mleft(speed);

	//movementlib.mright(speed);

	while (odometriya.distance - lvar.initialDistance < distance) {

		if (movementlib.flStop) break;

		lvar.dt =  movementlib.sensorscorrectiondelay / 1000;

		lvar.lDeltaD = lvar.lInitialDistance - odometriya.lDistance;

		lvar.rDeltaD = lvar.rInitialDistance - odometriya.rDistance;

		//lvar.error = lvar.rDeltaD - lvar.lDeltaD;

		lvar.y = odometriya.y - lvar.initY;

		lvar.x = odometriya.x - lvar.initX;

		//lvar.error = -Math.cos(lvar.initT) * (lvar.y - Math.tan(lvar.initT) * lvar.x);

		lvar.error = (lvar.initT - odometriya.teta);

		//print(lvar.error);

		lvar.integral = lvar.integral + lvar.error * lvar.dt;

		lvar.derative = (lvar.error - lvar.perror) / lvar.dt;

		lvar.correction = lvar.error * kp + lvar.derative * kd;

		movementlib.mleft(speed - lvar.correction);

		movementlib.mright(speed + lvar.correction);

		lvar.perror = lvar.error;

		//print(lvar.error);

		script.wait(movementlib.correctiondelay);

	}

	movementlib.mleft(0);

	movementlib.mright(0);

}



/*

If distance is zero - moving until the end

*/

movementlib.move_correction_sensors = function(speed, distance, kp, kd, ki, sLeft, sRight, sFront) {

	var lvar = {}

	lvar.initialDistance = odometriya.distance;

	lvar.perror = 0;

	lvar.integral = 0;

	while ((distance == 0 && (sFront.read() + sensorOffsetFront > length / 3)) || (distance > 0 && odometriya.distance - lvar.initialDistance < distance)) {

		if (movementlib.flStop) break;

		lvar.dt =  movementlib.sensorscorrectiondelay / 1000;

		lvar.leftWallDistance = sLeft.read() + sensorOffsetLeft;

		lvar.leftWallDistance = Math.min(lvar.leftWallDistance, movementlib.correctionthreshold);

		lvar.error = lvar.leftWallDistance - length / 2;

		lvar.integral = lvar.integral + lvar.error * lvar.dt;

		lvar.derative = (lvar.error - lvar.perror) / lvar.dt;

		lvar.correction = lvar.error * kp + lvar.derative * kd + ki * lvar.integral;

		movementlib.mleft(speed - lvar.correction);

		movementlib.mright(speed + lvar.correction);

		lvar.perror = lvar.error;

		script.wait(movementlib.sensorscorrectiondelay);

	}

	movementlib.mleft(0);

	movementlib.mright(0);

}



/*

If distance is zero - moving until the end

The same as before but it doesn't rotate the robot if the distance is higher than cellsize

(Useful for path movement)

*/

movementlib.move_semicorrection_sensors = function(speed, distance, kp, kd, ki, sLeft, sRight, sFront) {

	var lvar = {}

	lvar.initialDistance = odometriya.distance;

	lvar.perror = 0;

	lvar.integral = 0;

	while ((distance == 0 && (sFront.read() + sensorOffsetFront > length / 2)) || (distance > 0 && odometriya.distance - lvar.initialDistance < distance)) {

		if (movementlib.flStop) break;

		lvar.dt =  movementlib.sensorscorrectiondelay / 1000;

		lvar.leftWallDistance = sLeft.read() + sensorOffsetLeft;

		lvar.rightWallDistance = sRight.read() + sensorOffsetLeft;

		lvar.leftWallDistance = Math.min(lvar.leftWallDistance, length / 2);

		lvar.rightWallDistance = Math.min(lvar.rightWallDistance, length / 2);

		

		lvar.leftWallDistance = lvar.leftWallDistance <= lvar.rightWallDistance ? lvar.leftWallDistance : (length - lvar.rightWallDistance);

		

		lvar.error = lvar.leftWallDistance - length / 2;

		lvar.integral = lvar.integral + lvar.error * lvar.dt;

		lvar.derative = (lvar.error - lvar.perror) / lvar.dt;

		lvar.correction = lvar.error * kp + lvar.derative * kd + lvar.derative;

		if (lvar.leftWallDistance > length - (l / 2 + sensorOffsetLeft)) {

			lvar.correction = 0;

		}

		movementlib.mleft(speed - lvar.correction);

		movementlib.mright(speed + lvar.correction);

		lvar.perror = lvar.error;

		script.wait(movementlib.sensorscorrectiondelay);

	}

	movementlib.mleft(0);

	movementlib.mright(0);

}



movementlib.move_doublecorrection = function(speed, distance, kp, kd, ki, sLeft, sRight, sFront) {

	var lvar = {}

	lvar.initialDistance = odometriya.distance;

	lvar.initT = odometriya.teta;

	lvar.perror = 0;

	lvar.integral = 0;

	while ((distance == 0 && (sFront.read() + sensorOffsetFront > length / 3)) || (distance > 0 && odometriya.distance - lvar.initialDistance < distance)) {

		if (movementlib.flStop) break;

		lvar.dt =  movementlib.sensorscorrectiondelay / 1000;

		lvar.leftWallDistance = sLeft.read() + sensorOffsetLeft;

		lvar.rightWallDistance = sRight.read() + sensorOffsetLeft;

		lvar.leftWallDistance = Math.min(lvar.leftWallDistance, movementlib.correctionthreshold + sensorOffsetLeft);

		lvar.rightWallDistance = Math.min(lvar.rightWallDistance, movementlib.correctionthreshold + sensorOffsetLeft);

		lvar.leftWallExists = (lvar.leftWallDistance != movementlib.correctionthreshold + sensorOffsetLeft);

		lvar.rightWallExists = (lvar.rightWallDistance != movementlib.correctionthreshold + sensorOffsetLeft);

		

		//lvar.wallDistance = lvar.leftWallDistance <= lvar.rightWallDistance ? lvar.leftWallDistance : (length - lvar.rightWallDistance);

		lvar.wallDistance = 0;

		if (lvar.leftWallExists)

			lvar.wallDistance += lvar.leftWallDistance;

		if (lvar.rightWallExists) {

			if (lvar.wallDistance == 0) {

				lvar.wallDistance += (length - lvar.rightWallDistance);

			} else {

				lvar.wallDistance += (length - lvar.rightWallDistance);

				lvar.wallDistance /= 2;

			}

		}

		//print(lvar.leftWallDistance);

		//lvar.wallDistance = (lvar.leftWallDistance + length - lvar.rightWallDistance) / 2;

		

		//print("left: " + lvar.leftWallDistance, " right: " + lvar.rightWallDistance);

		//print("leftraw: " + sLeft.read(), " rightraw: " + sRight.read());

		

		//print(lvar.wallDistance + " " + lvar.leftWallDistance + " " + lvar.rightWallDistance);

		

		if (!lvar.leftWallExists && !lvar.rightWallExists) {

			//encoders correction

			//print("ENCODERS!");

			lvar.error = (lvar.initT - odometriya.teta);

		} else {

			//sensors correction

			//print("SENSORS!");

			lvar.error = lvar.wallDistance - length / 2;

		}

		//print(lvar.error);

		lvar.integral = lvar.integral + lvar.error * lvar.dt;

		lvar.derative = (lvar.error - lvar.perror) / lvar.dt;

		lvar.correction = lvar.error * kp + lvar.derative * kd + lvar.integral * ki;

		movementlib.mleft(speed - lvar.correction);

		movementlib.mright(speed + lvar.correction);

		lvar.perror = lvar.error;

		script.wait(movementlib.sensorscorrectiondelay);

	}

	movementlib.mleft(0);

	movementlib.mright(0);

}



/*

One left-hand movement iteration. Just call it inside a loop.

sLeft is the left sensor. sFront is the front sensor.

*/

movementlib.iterate_lefthand_state = 0



movementlib.iterate_lefthand = function(speed, sLeft, sRight, sFront, kp, kd, ki) {

	var lvar = {}

	lvar.leftWallExists = (sLeft.read() + sensorOffsetLeft < length);

	lvar.frontWallExists = (sFront.read() + sensorOffsetFront < length);

	if (!lvar.leftWallExists) {

		movementlib.rotate_encoderssmooth(speed, pi / 2);

		movementlib.move_correction_sensors(speed, 0, kp, kd, ki, sLeft, sRight, sFront);

		return;

	} else {

		if (lvar.frontWallExists) {

			movementlib.rotate_encoderssmooth(speed, -pi / 2);

			return;

		} else {

			movementlib.move_correction_sensors(speed, 0, kp, kd, ki, sLeft, sRight, sFront);

			return;

		}

	}

}



/*

Movement with known path.

path - array of cell indexes

sRight - can be undefined (if you don't have one)

*/

movementlib.move_path = function(speed, path, mazesizeX, mazesizeY, sLeft, sRight, sFront, kp, kd, ki) {

	if (kp == undefined)

		kp = 0.1

	if (kd == undefined)

		kd = 0.1

	if (ki == undefined)

		ki = 0.1

	var lvar = {}

	var result = "";

	

	path = path.reverse();

	

	

	var initPos = trikTaxi.getPos(path[0], mazesizeX, mazesizeY);

	//odometriya.x = initPos[0] * length;

	//odometriya.y = -initPos[1] * length;

	var lastTeta = odometriya.teta;

	//print(lastTeta);

	for (i = 0; i < path.length - 1; i++) {

		var curpos = trikTaxi.getPos(path[i], mazesizeX, mazesizeY);

		var nextpos = trikTaxi.getPos(path[i + 1], mazesizeX, mazesizeY);

		var delta = [nextpos[0] - curpos[0], nextpos[1] - curpos[1]];

		

		//delta[0] = -delta[0];

		//delta[1] = -delta[1];

		

		

		//delta[0] = -delta[0]

		//delta[1] = -delta[1]

		

		

		

		var angle = Math.atan2(-delta[1], delta[0]);

		var delta_angle = angle - lastTeta;

		

		

		if (delta_angle > pi)

			delta_angle = delta_angle - 2 * pi;

		else if (delta_angle < -pi)

			delta_angle = 2 * pi + delta_angle;

		

		switch (Math.round(delta_angle * 100) / 100) {

			case 1.57:

				result += "L";

				break;

			case -1.57:

				result += "R";

				break;

			case 3.14:

				result += "RR";

				break;

			case -3.14:

				result += "LL";

				break;

		}

		

		//print(delta, " ", delta_angle, " ", angle);

		result += "F";

		movementlib.rotate_encoderssmooth(speed, delta_angle);

		movementlib.move_doublecorrection(speed, length, kp, kd, ki, sLeft, sRight, sFront);

		//movementlib.move_semicorrection_sensors(speed, length, kp, kd, ki, sLeft, sRight, sFront);

		//movementlib.move_correction(speed, length, kp, kd, ki);

		//movementlib.move_encoders(speed, length)

		lastTeta = angle;

	}

	return result;

}



movementlib.move_pathcorrection = function(speed, path, mazesizeX, mazesizeY, sLeft, sRight, sFront, kp, kd, ki) {

	if (kp == undefined)

		kp = 0.1

	if (kd == undefined)

		kd = 0.1

	if (ki == undefined)

		ki = 0.1

	var lvar = {}

	path = path.reverse();

	var initPos = trikTaxi.getPos(path[0], mazesizeX, mazesizeY);

	odometriya.x = initPos[0] * length;

	odometriya.y = -initPos[1] * length;

	var lastTeta = odometriya.teta;

	var xline = undefined;

	var yline = undefined;

	for (i = 0; i < path.length - 1; i++) {

		var curpos = trikTaxi.getPos(path[i], mazesizeX, mazesizeY);

		var nextpos = trikTaxi.getPos(path[i + 1], mazesizeX, mazesizeY);

		xline = true;

		yline = true;

		var jlast = curpos;

		var jlastindex = i;

		for (var j = i + 1; j < path.length && (xline || yline); j++) {

			var jpos = trikTaxi.getPos(path[j], mazesizeX, mazesizeY);

			if (jpos[0] != jlast[0])

				xline = false;

			if (jpos[1] != jlast[1])

				yline = false;

			if (xline || yline) {

				jlast = jpos;

				jlastindex = j;

			}

		}

		nextpos = jlast;

		var delta = [nextpos[0] - curpos[0], nextpos[1] - curpos[1]];

		print(delta + " " + jlastindex + " " + jpos);

		var angle = Math.atan2(-delta[1], delta[0]);

		var delta_angle = angle - lastTeta;

		if (delta_angle > pi)

			delta_angle = delta_angle - 2 * pi;

		else if (delta_angle < -pi)

			delta_angle = 2 * pi + delta_angle;

		movementlib.rotate_encoderssmooth(speed, delta_angle);

		movementlib.move_doublecorrection(speed, length * (Math.abs(delta[0]) + Math.abs(delta[1])), kp, kd, ki, sLeft, sRight, sFront);

		lastTeta = angle;

		i = jlastindex - 1;

	}

}



//##################

//REGION END

//##################





//##################

//REGION: TrikTaxi (Path Construction)

//##################

//This code requiers:

//-

/*

Usage:

1) Create the maze matrix

2) Set trikTaxi.walls

3) Use A* (or something else but dunno why)

*/

var trikTaxi = {}



//Write walls here (between which cells walls are). PUT THEM IN ASCENDING ORDER! (x, y) where x < y

trikTaxi.walls = ["2, 3", "6, 7", "3, 11", "4, 12", "12, 13", "29, 37", "36, 37", "51, 59"]



trikTaxi.getPos = function (cell, xsize, ysize) {

    return [cell % xsize, Math.floor(cell/ysize)]

}



trikTaxi.getEuclideanDistance = function (cell1, cell2, xsize, ysize) {

    p1 = trikTaxi.getPos(cell1, xsize, ysize)

    p2 = trikTaxi.getPos(cell2, xsize, ysize)

    deltax2 = (p1[0] - p2[0])

    deltax2 *= deltax2

    deltay2 = (p1[1] - p2[1])

    deltay2 *= deltay2

    return Math.sqrt(deltax2 + deltay2)

}



trikTaxi.getManhattanDistance = function (cell1, cell2, xsize, ysize) {

    p1 = trikTaxi.getPos(cell1, xsize, ysize)

    p2 = trikTaxi.getPos(cell2, xsize, ysize)

    return Math.abs(p1[0] - p2[0]) + Math.abs(p1[1] - p2[1])

}



trikTaxi.getNeighbors = function (cell, xsize, ysize) {

    result = []

    up = cell - xsize

    if (up >= 0 && up < xsize * ysize && trikTaxi.walls.indexOf(up + ", " + cell) == -1)

        result.push(up)

    right = cell + 1

    if (right % xsize == 0) {

        right = -1

    }

    if (right >= 0 && right < xsize * ysize && trikTaxi.walls.indexOf(cell + ", " + right) == -1)

        result.push(right)

    down = cell + xsize

    if (down >= 0 && down < xsize * ysize && trikTaxi.walls.indexOf(cell + ", " + down) == -1)

        result.push(down)

    left = cell - 1

    if (left % xsize == xsize - 1) {

        left = -1

    }

    if (left >= 0 && left < xsize * ysize && trikTaxi.walls.indexOf(left + ", " + cell) == -1)

        result.push(left)

    return result

}



trikTaxi.reconstructPath = function (start, end, tree) {

    path = []

    x = end

    while (x != start) {

        path.push(x)

        x = tree[x]

        if (x === undefined)

            return []

    }    

    path.push(start)

    return path

}



/*

Breadth First Search

start is int

end is int

maze is a binary array of cells

xsize, ysize are the maze sizes

*/

trikTaxi.bfs = function (start, end, maze, xsize, ysize) {

    var open = [start]

    var closed = []

    var tree = new Array(xsize * ysize)

    while (open.length > 0) {

        var x = open.shift();

        if (x == end) {

            return trikTaxi.reconstructPath(start, end, tree)

        }



        if (closed.indexOf(x) == -1 && maze[x]) {

            closed.push(x);

            var neighbors = trikTaxi.getNeighbors(x, xsize, ysize);

            for (i = 0; i < neighbors.length; i++) {

                if (closed.indexOf(neighbors[i]) == -1 && maze[neighbors[i]]) {

                    if (tree[neighbors[i]] == undefined)

                        tree[neighbors[i]] = x

                    open.push(neighbors[i]);

                }

            }

        }

    }

    return []

} 



trikTaxi.fnilbfs = function (start, arr, maze, xsize, ysize) {

    var open = [start]

    var closed = []

    var tree = new Array(xsize * ysize)

    while (open.length > 0) {

        var x = open.shift();

        if (arr.indexOf(x) == -1) {

            return trikTaxi.reconstructPath(start, end, tree)

        }



        if (closed.indexOf(x) == -1 && maze[x]) {

            closed.push(x);

            var neighbors = trikTaxi.getNeighbors(x, xsize, ysize);

            for (i = 0; i < neighbors.length; i++) {

                if (closed.indexOf(neighbors[i]) == -1 && maze[neighbors[i]]) {

                    if (tree[neighbors[i]] == undefined)

                        tree[neighbors[i]] = x

                    open.push(neighbors[i]);

                }

            }

        }

    }

    return []

} 



trikTaxi.magicbfs = function (start, end, maze, xsize, ysize, startRot) {

    var open = [start]

    var closed = []

    var tree = new Array(xsize * ysize)

	var rots = new Array(xsize * ysize)

	rots[start] = startRot;

    while (open.length > 0) {

        var x = open.shift();

        if (x == end) {

            return trikTaxi.reconstructPath(start, end, tree)

        }



        if (closed.indexOf(x) == -1 && maze[x]) {

            closed.push(x);

            var neighbors = trikTaxi.getNeighbors(x, xsize, ysize);

			for (i = 0; i < neighbors.length; i++) {

				

				var curpos = trikTaxi.getPos(x, xsize, ysize);

				var nextpos = trikTaxi.getPos(neighbors[i], xsize, ysize);

				var delta = [nextpos[0] - curpos[0], nextpos[1] - curpos[1]];

				var angle = Math.atan2(-delta[1], delta[0]);

				var dir = Math.round(angle / (2 * pi) * 4);

				if (dir == 4)

					dir = 0;

				

				if (dir == rots[x]) {

					open.push(neighbors[i]);

					rots[neighbors[i]] = dir;

				}

			}

            for (i = 0; i < neighbors.length; i++) {

                if (closed.indexOf(neighbors[i]) == -1 && maze[neighbors[i]]) {

                    if (tree[neighbors[i]] == undefined)

                        tree[neighbors[i]] = x

					

					var curpos = trikTaxi.getPos(x, xsize, ysize);

					var nextpos = trikTaxi.getPos(neighbors[i], xsize, ysize);

					var delta = [nextpos[0] - curpos[0], nextpos[1] - curpos[1]];

					var angle = Math.atan2(-delta[1], delta[0]);

					var dir = Math.round(angle / (2 * pi) * 4);

					if (dir == 4)

						dir = 0;

					

                    open.push(neighbors[i]);

					rots[neighbors[i]] = dir;

                }

            }

        }

    }

    return []

} 



/*

Depth First Search

start is int

end is int

maze is a binary array of cells

xsize, ysize are the maze sizes

*/

trikTaxi.dfs = function (start, end, maze, xsize, ysize) {

    var open = [start]

    var closed = []

    var tree = new Array(xsize * ysize)

    while (open.length > 0) {

        var x = open.shift();

	//print(x);

        if (x == end) {

            return trikTaxi.reconstructPath(start, end, tree)

        }



        if (closed.indexOf(x) == -1 && maze[x]) {

            closed.push(x);

            var neighbors = trikTaxi.getNeighbors(x, xsize, ysize);

            for (i = 0; i < neighbors.length; i++) {

                if (closed.indexOf(neighbors[i]) == -1 && maze[neighbors[i]]) {

                    if (tree[neighbors[i]] == undefined)

                        tree[neighbors[i]] = x

                    open.push(neighbors[i])

                    break;

                }

            }

        }

    }

	return [];

}



/*

A*

start is int

end is int

maze is a binary array of cells

xsize, ysize are the maze sizes

*/

trikTaxi.astar = function (start, end, maze, xsize, ysize) {

    var lvar = {}

    lvar.open = [start]

    lvar.closed = []

    lvar.gscores = new Array(xsize * ysize)

    lvar.fscores = new Array(xsize * ysize)

    for (i = 0; i < xsize * ysize; i++) {

        lvar.gscores[i] = Infinity

        lvar.fscores[i] = Infinity

    }

    lvar.gscores[start] = 0

    lvar.fscores[start] = trikTaxi.getManhattanDistance(start, end, xsize, ysize)

    lvar.tree = new Array(xsize * ysize)

    while (lvar.open.length > 0) {

        lvar.x = lvar.open[lvar.open.length - 1]

        lvar.xi = lvar.open.length - 1

        for (i = 0; i < lvar.open.length; i++) {

            if (lvar.fscores[lvar.open[i]] < lvar.fscores[lvar.x]) {

                lvar.x = lvar.open[i]

                lvar.xi = i

            }

        }



        if (lvar.x == end) {

            return trikTaxi.reconstructPath(start, end, lvar.tree)

        }

        lvar.open.splice(lvar.xi, 1)

        lvar.closed.push(lvar.x)



        lvar.neighbors = trikTaxi.getNeighbors(lvar.x, xsize, ysize)

        

        for (i = 0; i < lvar.neighbors.length; i++) {

            lvar.y = lvar.neighbors[i]

            if (!maze[lvar.y] || lvar.closed.indexOf(lvar.y) > -1) {

                continue

            }

            

            lvar.tentativeg = lvar.gscores[lvar.x] + trikTaxi.getEuclideanDistance(lvar.x, lvar.y, xsize, ysize)



            if (lvar.open.indexOf(lvar.y) == -1) {

                lvar.open.push(lvar.y)

            } else if (lvar.tentativeg >= lvar.gscores[lvar.y]) {

                continue

            }

            lvar.tree[lvar.y] = lvar.x

            lvar.gscores[lvar.y] = lvar.tentativeg

            lvar.fscores[lvar.y] = lvar.gscores[lvar.y] + trikTaxi.getManhattanDistance(lvar.y, end, xsize, ysize)

        }

    }

    return []

}



trikTaxi.parsePath = function(pth, xSize, ySize, startTeta) {

	var result = "";

	var lastTeta = startTeta;

	var path = pth.reverse();

	for (var i = 0; i < path.length - 1; i++) {

		var curpos = trikTaxi.getPos(path[i], xSize, ySize);

		var nextpos = trikTaxi.getPos(path[i + 1], xSize, ySize);

		var delta = [nextpos[0] - curpos[0], nextpos[1] - curpos[1]];

		var angle = Math.atan2(-delta[1], delta[0]);

		var sign = angle - lastTeta > 0 ? 1 : -1;

		//var delta_angle = Math.min(Math.abs(angle - lastTeta), 2 * pi - Math.abs(lastTeta - angle)) * sign;

		var delta_angle = angle - lastTeta;

		if (delta_angle > pi)

			delta_angle = delta_angle - 2 * pi;

		else if (delta_angle < -pi)

			delta_angle = 2 * pi + delta_angle;

		var rangle = Math.round(delta_angle * 100) / 100;

		switch (rangle) {

			case -1.57:

				result += "R";

				break;

			case 1.57:

				result += "L";

				break;

		}

		result += "F";

		lastTeta = angle;

	}

	//print(result);

	return result;

}

//##################

//REGION END

//##################



//##################

//REGION DISPLAY

//##################



var display = {}



display.print = function(text, x, y) {

	if (x == undefined || y == undefined) {

		x = 10;

		y = 10;

	}

	brick.display().addLabel(text, x, y);

	brick.display().redraw();

}



//##################

//REGION END

//##################

wait = script.wait;
sign = function(n) { return n > 0 ? 1 : n = 0 ? 0 : -1; }
sqr = function(n) { return n * n; }
sqrt = Math.sqrt;
min = function(a, b) { return a < b ? a : b; }
max = function(a, b) { return a > b ? a : b; }
abs = Math.abs;
sin = Math.sin;
cos = Math.cos;
round = Math.round;