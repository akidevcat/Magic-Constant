var __interpretation_started_timestamp__;
// Параметры робота
var pi = 3.141592653589793;
var d = 5.6 // Диаметр колеса, см
var l = 17.5 // База, см
var x = 0 // Начальные координаты робота
var y = 0
var a = 0

// Моторы
var mLeft = brick.motor(M4).setPower;
var mRight = brick.motor(M3).setPower;
var cpr = 360 // Показания энкодера за оборот

// Энкодеры
var eLeft = brick.encoder(E4);
var eRight = brick.encoder(E3);
eLeft.reset();
eRight.reset();

// Длина клетки
var cellLength = 52.5 * cpr / (pi * d);
var length = 69

// Датчики расстояния
var svFront = brick.sensor(A1).read;
var svLeft = brick.sensor(A2).read;
//var svRigth = brick.sensor(A2).read;

var sLeft = 0;
var sFront = 0;

var direction = 0; // куда смотрит робот
var azimut = 0;


var kp = 0.5;
var kd = 1;
var u = 0;
var err = 0;
var err_old = 0;

var v = 90; // velocity
var dist = 36;

var is_path_left = false;


var debug = function() 
{
	//mLeft(0);
	//mRight(0);
	//script.wait(1000);
	//print('direction: ', direction * 90 % 360); 
	//print('cells_count: ', cells_count);
}

/*
var hole_left = function()
{
	mLeft(45);
	mRight(80);
	script.wait(2700);
	mLeft(v);
	mRight(v);
	forward(32);
	direction--;
	cells_count = cells_count + 2;
	debug();
}
*/

var hole_left = function()
{
	mLeft(v);
	mRight(v);
	forward(25);
	cells_count++;
	update_location();
	eLeft.reset();
	debug();
	
	rotate(-90);
	forward(69);
	cells_count++;
	update_location();
	eLeft.reset();
	debug();
}


var update_location = function()
{
	cells_count++;
	
	azimut = direction * 90;
	if (azimut < 0)
	{
		azimut = azimut + 360;
	}
		
	switch (azimut) {
		case 0: 
			y++;
			break;
		case 90: 
			x++;
			break;
		case 180: 
			y--;
			break;
		case 270: 
			x--;
			break;
	}
	
	//print(azimut, ' ', x, ',', y);
	//debug();
	
	eLeft.reset();
}


var forward_kp = function()
{
	eLeft.reset();
	encLeft = eLeft.read();
	sFront = svFront();
	
	var is_hole_left = false;
	
	while(sFront > 30)
	{
		encLeft = eLeft.read();
		sLeft = svLeft();

		if(sLeft > 40)
		{
			is_path_left = true;
			return;
		
		} else
		{
			err = sLeft - 31.5;
			u = err * kp + (err - err_old) * kd;
		
			mLeft(v - u);
			mRight(v + u);
			
			err_old = err;
		}
		
		if(encLeft > length * cpr / (pi * d))
		{
			update_location();
			debug();
		}
		
		sFront = svFront();
		script.wait(1);
	}
	
	mLeft(0);
	mRight(0);
}

var forward_enc = function(length)
{
	eLeft.reset();
	encLeft = eLeft.read();
	if(length > 0)
	{
		while(encLeft < length * cpr / (pi * d))
		{
			encLeft = eLeft.read();
			
			
			mLeft(100);
			mRight(100);
			script.wait(1);
		}
	} else
	{
		while(encLeft > length * cpr / (pi * d))
		{
			encLeft = eLeft.read();
			
			
			mLeft(-100);
			mRight(-100);
			script.wait(1);
		}	
	}
	mLeft(0);
	mRight(0);
}


var rotate = function(angle)
{
	forward_enc(8.75);
	eLeft.reset();
	eRight.reset();
	if(angle == -90)
	{
		encRight = 0;
		while(Math.abs(encRight) < ((pi * l) / 4) / (pi * d) * cpr)
		{
			encRight = eRight.read();
			mLeft(-100);
			mRight(100);
			script.wait(1);
		}
		mLeft(0);
		mRight(0);
		direction--;
	} else
	{
		encLeft = 0;
		while(encLeft < ((pi * l) / 4) / (pi * d) * cpr)
		{
			encLeft = eLeft.read();
			mLeft(100);
			mRight(-100);
			script.wait(1);
		}
		mLeft(0);
		mRight(0);
		direction++;
	}
	forward_enc(-8.75);
}

var cells_count = 0;

var main = function()
{
	__interpretation_started_timestamp__ = Date.now();
	
	var lines = script.readAll('input.txt');
	dest = lines[0]
	
	script.wait(10);
	
	while(cells_count < dest)
	{	
		sLeft = svLeft();
		sFront = svFront();
		if(sLeft > dist)
		{
			rotate(-90);
			
			if (is_path_left == true)
			{
				mLeft(v);
				mRight(v);
				forward_enc(70);
				update_location();
				is_path_left = false;
			}
			
		} else
		{
			if (sFront > dist)
			{
				forward_kp();
				
				if (is_path_left == true)
				{
					mLeft(v);
					mRight(v);
					forward_enc(22);
					update_location();
					
				}				
				
			} else
			{
				rotate(90);
			}
		}
		script.wait(1);
				
	}
	
	brick.display().addLabel("("+x+","+y+")", 1, 1);
	brick.display().redraw();

	return;
}
